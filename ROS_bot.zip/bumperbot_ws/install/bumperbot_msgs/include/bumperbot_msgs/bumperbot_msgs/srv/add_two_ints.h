// generated from rosidl_generator_c/resource/idl.h.em
// with input from bumperbot_msgs:srv/AddTwoInts.idl
// generated code does not contain a copyright notice

#ifndef BUMPERBOT_MSGS__SRV__ADD_TWO_INTS_H_
#define BUMPERBOT_MSGS__SRV__ADD_TWO_INTS_H_

#include "bumperbot_msgs/srv/detail/add_two_ints__struct.h"
#include "bumperbot_msgs/srv/detail/add_two_ints__functions.h"
#include "bumperbot_msgs/srv/detail/add_two_ints__type_support.h"

#endif  // BUMPERBOT_MSGS__SRV__ADD_TWO_INTS_H_
